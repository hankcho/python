some_words = ["potatoes", "shallow", "voice", "conversation",
            "more", "myself", "thirty", "certainly",
            "needle", "learn"]
