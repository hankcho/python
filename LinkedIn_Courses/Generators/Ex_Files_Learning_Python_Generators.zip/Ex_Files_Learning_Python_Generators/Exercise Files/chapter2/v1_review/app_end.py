def square(num):
    my_list = []
    for n in range(1, num):
        my_list.append(n ** 2)
    return my_list

print(square(10))

my_list = [num ** 2 for num in range(1,10)]

print(my_list)