def square(num):
    my_list = []
    for n in range(1, num):
        my_list.append(n ** 2)
    return my_list
