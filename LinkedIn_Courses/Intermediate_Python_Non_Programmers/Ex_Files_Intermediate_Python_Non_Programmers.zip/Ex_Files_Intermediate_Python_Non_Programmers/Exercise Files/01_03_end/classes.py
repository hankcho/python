class Dog:
    info = "a domesticated carnivorous mammal that typically has a long snout, an acute sense of smell, nonretractable claws, and a barking, howling, or whining voice."


print(Dog.info)

# Create a class for something around you in the room.
# Create a class variable inside the class

class Square:
    sides = 4
