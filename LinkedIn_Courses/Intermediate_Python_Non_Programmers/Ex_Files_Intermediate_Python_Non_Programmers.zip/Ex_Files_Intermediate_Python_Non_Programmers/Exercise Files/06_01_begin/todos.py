import sys

# Read File

# Add Todo

# Remove Todo

# Save File

# Print List
print("\nHere's your ToDo list:\n")
print(“1. Walk the Dog”)
print(“2. Buy Cheese”)

# Print Commands
print("\n*******************************\n")
print(f"To view ToDos:\n{sys.argv[0]}")
print(f"\nTo add a ToDo:\n{sys.argv[0]} add \"Clean Room\"\n")
print(f"To remove or complete ToDo:\n{sys.argv[0]} remove 2\n")
